import pandas as pd
import random

def create_new_airline_feedback_data():
    """Generate a new synthetic airline feedback dataset for sentiment analysis."""
    new_feedbacks = [
        "The flight was delayed but the lounge service was excellent.",
        "Flight attendants were very helpful during the journey.",
        "The food was terrible and the seats were cramped.",
        "Had a smooth flight, but the boarding process was disorganized.",
        "The airline provided good updates during the delay.",
        "Excellent service, but the flight was too short.",
        "The Wi-Fi was non-functional for most of the flight.",
        "Comfortable flight with friendly staff.",
        "The aircraft was clean but the food was mediocre.",
        "I experienced significant turbulence but the staff were reassuring.",
        "The flight was cancelled and there was no alternative provided.",
        "In-flight entertainment was poor, very limited options.",
        "The check-in process was efficient, but the boarding was chaotic.",
        "Good value for money, would fly with this airline again.",
        "The staff were very professional, but the flight was too noisy.",
        "The flight experience was average; nothing exceptional.",
        "The baggage claim was quick but the food service needs improvement.",
        "Had a pleasant experience, but the seat recline was not functional.",
        "The cabin crew were polite but the flight was quite turbulent.",
        "The flight was on time, and the customer service was excellent.",
        "The legroom was uncomfortable and the cabin was too warm.",
        "The boarding experience was smooth but the flight was delayed.",
        "Had a great flight experience, staff were accommodating.",
        "The entertainment system was broken, which was disappointing.",
        "Flight was good, but the communication during delays could improve.",
        "The food was surprisingly good, and the flight was smooth.",
        "The cabin temperature was too low for comfort during the flight.",
        "Friendly staff, but the flight was quite bumpy.",
        "The flight was canceled and the compensation was inadequate.",
        "The boarding process was well organized but the flight was delayed.",
        "Overall, the flight was satisfactory, but the food could be improved.",
        "The flight was comfortable, but the check-in process was slow.",
        "The staff provided excellent service, but the flight was delayed.",
        "The in-flight service was decent, but the seat was uncomfortable.",
        "The flight was punctual, but the cabin was too cold.",
        "The boarding was chaotic, but the flight was pleasant.",
        "The check-in was smooth, but the flight had too many delays.",
        "Comfortable flight with good service, but the food was average.",
        "The in-flight entertainment system was lacking in options.",
        "The flight was delayed but the staff were very accommodating.",
        "The flight was smooth and the customer service was excellent.",
        "The flight was on time, but the seats were too cramped.",
        "Overall, a good experience, but the boarding could be improved.",
        "The food was okay, but the staff were very friendly.",
        "The flight was delayed significantly, but the crew handled it well.",
        "The flight was comfortable, but the legroom was insufficient.",
        "The check-in process was quick, but the food quality was poor.",
        "The flight was pleasant, but the entertainment options were limited.",
        "The cabin was clean, but the flight was too noisy.",
        "The flight was on time, but the in-flight service was lacking.",
        "The boarding process was smooth but the flight had turbulence.",
        "Good flight experience overall, but the food could be improved.",
        "The in-flight service was excellent, but the flight was delayed.",
        "The flight was comfortable, but the check-in process was frustrating.",
        "The staff were helpful, but the flight had multiple delays.",
        "The food was decent, but the flight had significant turbulence.",
        "The flight was on time, but the seats were uncomfortable.",
        "Overall, the experience was good, but the boarding process needs work.",
        "The flight was smooth, but the in-flight entertainment was poor.",
        "The cabin crew were very attentive, but the flight was delayed.",
        "The check-in process was efficient, but the food was lackluster.",
        "The flight was delayed but the communication was clear.",
        "The staff were friendly, but the flight was very crowded.",
        "The food was good, but the flight had some turbulence.",
        "The boarding was chaotic, but the flight was comfortable.",
        "The flight was delayed, but the staff managed the situation well.",
        "The cabin was clean, but the food quality was not great.",
        "The flight was good overall, but the check-in process could be improved.",
        "The flight was pleasant, but the in-flight entertainment was lacking.",
        "The flight was on time, but the legroom was insufficient.",
        "The food was poor, but the flight attendants were friendly.",
        "The flight was delayed but the overall experience was good.",
        "The staff were professional, but the flight had many interruptions.",
        "The boarding process was smooth, but the flight was noisy.",
        "The flight was comfortable, but the food was disappointing.",
        "The check-in process was slow, but the flight was pleasant.",
        "The flight was delayed, but the staff were very accommodating.",
        "The cabin temperature was uncomfortable, but the flight was on time.",
        "The flight was good, but the food could have been better.",
        "The entertainment options were limited, but the flight was smooth.",
        "The staff were helpful, but the flight had some turbulence.",
        "The food was mediocre, but the overall flight experience was good.",
        "The check-in was efficient, but the flight had several delays.",
        "The flight was on time, but the cabin crew could have been more attentive.",
        "The flight was delayed, but the service was good overall.",
        "The legroom was insufficient, but the in-flight service was decent.",
        "The boarding process was quick, but the flight was noisy.",
        "The food was average, but the flight experience was overall good.",
        "The flight was comfortable, but the entertainment system was lacking.",
        "The check-in was smooth, but the food quality was disappointing.",
        "The flight was on time, but the cabin temperature was too high.",
        "The staff were very friendly, but the flight had some turbulence.",
        "The flight was good, but the legroom was not sufficient.",
        "The boarding process was efficient, but the food was lackluster.",
        "The flight was delayed but the staff handled it well.",
        "The overall experience was good, but the in-flight entertainment was poor.",
        "The food was acceptable, but the flight had significant delays.",
        "The flight was smooth, but the legroom could be improved.",
        "The staff were professional, but the flight was too crowded.",
        "The check-in process was efficient, but the food was below average.",
        "The flight was delayed, but the overall experience was satisfactory."
    ]
    
    sentiments = ["Positive", "Negative", "Neutral"]

    # Generate synthetic dataset
    new_data = {
        'feedback': [random.choice(new_feedbacks) for _ in range(100)],
        'sentiment': [random.choice(sentiments) for _ in range(100)]
    }
    
    return pd.DataFrame(new_data)

def append_to_csv(df, filename='airline_feedback.csv'):
    """Append the DataFrame to an existing CSV file."""
    df.to_csv(filename, mode='a', header=False, index=False)
    print(f"New data appended to {filename}")

if __name__ == "__main__":
    # Create new synthetic airline feedback data
    new_df = create_new_airline_feedback_data()
    
    # Append new data to the existing CSV file
    append_to_csv(new_df)
