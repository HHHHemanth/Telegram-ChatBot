import logging
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors
import nltk
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackContext, filters, CallbackQueryHandler
import csv
from sklearn.model_selection import train_test_split

# Enable logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Download NLTK data files
nltk.download('stopwords')
nltk.download('punkt')

# Load the dataset from the local CSV file
filename = 'merged_file.csv'  # Update this to the path of your local CSV file
data = pd.read_csv(filename, encoding='latin-1')

# Prepare the data
queries = data['queries'].tolist()
responses = data['replies'].tolist()

# Split the data into training and testing sets
queries_train, queries_test, responses_train, responses_test = train_test_split(queries, responses, test_size=0.2, random_state=42)

# Initialize the TF-IDF Vectorizer with more features
vectorizer = TfidfVectorizer(stop_words='english', ngram_range=(1, 2), max_features=5000)
query_vectors_train = vectorizer.fit_transform(queries_train)

# Initialize the Nearest Neighbors model
model = NearestNeighbors(n_neighbors=1, metric='cosine')
model.fit(query_vectors_train)

def get_response(new_query):
    new_query_vector = vectorizer.transform([new_query])
    distance, index = model.kneighbors(new_query_vector)
    return responses_train[index[0][0]]

# Replace 'your_bot_token' with the token you received from BotFather
BOT_TOKEN = '7425977219:AAHCu9DG1XaiSi87T7OtAkqIpSaKHC--2us'

# Initialize a dictionary to manage user states
user_states = {}

async def start(update: Update, context: CallbackContext) -> None:
    """Handle the /start command."""
    user_id = update.message.from_user.id
    user_states[user_id] = 'waiting_for_query'
    await update.message.reply_text('👋 Hello! I am your friendly bot. Send me a message and I will respond. 😊')

async def handle_message(update: Update, context: CallbackContext) -> None:
    """Handle incoming messages from users."""
    user_id = update.message.from_user.id
    user_message = update.message.text

    if user_id not in user_states:
        user_states[user_id] = 'waiting_for_query'

    if user_states[user_id] == 'waiting_for_query':
        response = get_response(user_message)  # Get response from ML model
        store_message(user_message, response)
        user_states[user_id] = 'waiting_for_continue'
        
        keyboard = [
            [InlineKeyboardButton("👍 Yes", callback_data='yes')],
            [InlineKeyboardButton("👋 No", callback_data='no')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(response + "\n\nDo you want to continue the conversation?", reply_markup=reply_markup)
    elif user_states[user_id] == 'waiting_for_feedback':
        await handle_feedback(update, context)  # Call the feedback handling function
    else:
        await update.message.reply_text('I didn’t understand that. Please reply with the button options provided.')

async def handle_feedback(update: Update, context: CallbackContext) -> None:
    """Handle user feedback."""
    user_id = update.message.from_user.id
    user_message = update.message.text

    if user_id in user_states and user_states[user_id] == 'waiting_for_feedback':
        try:
            # Save feedback to CSV
            with open('feedback.csv', mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([user_message])
            
            # Send thank you message
            await update.message.reply_text(
                '🙏 Thank you for your feedback! We appreciate your input. \n\n'
                'Visit our website for more information: Global_Airways(https://Global_Airways.com) \n'
                'Feel free to reach out if you need further assistance. 😊'
            )
            
            # Reset state to waiting for query
            user_states[user_id] = 'waiting_for_query'
            await update.message.reply_text('👍 You can now send me another message if you need further assistance.')
        except Exception as e:
            logger.error(f"Error saving feedback: {e}")
            await update.message.reply_text("There was an error saving your feedback. Please try again.")
    else:
        await update.message.reply_text("It seems there's an issue with your request. Please start a new conversation.")
        user_states[user_id] = 'waiting_for_query'

async def button(update: Update, context: CallbackContext) -> None:
    """Handle button clicks."""
    query = update.callback_query
    user_id = query.from_user.id
    choice = query.data

    if choice == 'yes':
        user_states[user_id] = 'waiting_for_query'
        await query.edit_message_text('👍 Great! Send me another message when you are ready.')
    elif choice == 'no':
        user_states[user_id] = 'waiting_for_feedback'
        await query.edit_message_text('✨Please provide your feedback, as this helps our website to grow.😊')
    else:
        await query.edit_message_text('I didn’t understand that. Please try again.')

def store_message(user_message, response):
    """Store the user message and response in a CSV file."""
    try:
        with open('user_messages.csv', mode='a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([user_message, response])
    except Exception as e:
        logger.error(f"Error saving message: {e}")

def main() -> None:
    """Start the bot."""
    application = Application.builder().token(BOT_TOKEN).build()

    # Handle /start command
    application.add_handler(CommandHandler('start', start))

    # Handle any text message
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # Handle button presses
    application.add_handler(CallbackQueryHandler(button))

    # Handle user feedback
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_feedback))

    logger.info('Bot is starting...')
    application.run_polling()

if __name__ == '__main__':
    main()
